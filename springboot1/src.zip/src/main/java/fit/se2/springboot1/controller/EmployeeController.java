package fit.se2.springboot1.controller;

import fit.se2.springboot1.model.Company;
import fit.se2.springboot1.model.Employee;
import fit.se2.springboot1.repository.CompanyRepository;
import fit.se2.springboot1.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "/employee")
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	CompanyRepository companyRepository;

	@RequestMapping(value = "/list")

	public String getAllEmployee(@RequestParam(value = "company", required = false, defaultValue = "0") Long comId,
	                             @RequestParam(value = "sort", required = false, defaultValue = "0") int sortMode,
	                             Model model) {
		List<Company> companies = companyRepository.findAll();
		model.addAttribute("companies", companies);
		//-------------------
		Sort.Direction sortOrder = Sort.Direction.DESC;
		String sortColumn = "id";
		if (sortMode == 1 || sortMode == 2) {
			sortOrder = Sort.Direction.ASC;
		}
		if (sortMode == 2 || sortMode == 3) {
			sortColumn = "name";
		}
		//----------------------
		List<Employee> employees = null;
		if (comId != 0) {
			Optional<Company> comp = companyRepository.findById(comId);
			if (comp.isPresent()) {
				employees = employeeRepository.findByCompany(
						comp.get(),
						Sort.by(sortOrder, sortColumn)
				);
			}
		}
		//------------
		employees = null;
		if (comId != 0) {
			Optional<Company> comp = companyRepository.findById(comId);
			if (comp.isPresent()) {
				employees = employeeRepository.findByCompany(
						comp.get(),
						Sort.by(sortOrder, sortColumn)
				);
			}
		}
		//-------------------------------
		employees = employeeRepository.findAll();
		model.addAttribute("employees", employees);

		model.addAttribute("companies", companies);
		model.addAttribute("comId", comId);
		model.addAttribute("sortMode", sortMode);
		return "employeeList";
	}

	@RequestMapping(value = "/detail/{id}")
	public String getEmployeeById(@PathVariable(value = "id") Long id, Model model) {
		Employee employee = employeeRepository.getById(id);
		model.addAttribute("employee", employee);
		return "employeeDetail";
	}

	@GetMapping(value = "/update/{id}")
	public String updateEmployee(
			@PathVariable(value = "id") Long id, Model model) {
		Employee employee = employeeRepository.getById(id);
		model.addAttribute(employee);
		return "employeeUpdate";
	}

	@PostMapping(value = "/save")
	public String saveUpdate(Employee employee) {
		employeeRepository.save(employee);
		return "redirect:/employee/list";
	}

	@GetMapping(value = "/add")
	public String addEmployee(Model model) {
		Employee employee = new Employee();
		List<Company> companies = companyRepository.findAll();
		model.addAttribute("employee", employee);
		model.addAttribute("companies", companies);
		return "employeeAdd";
	}

	@RequestMapping(value = "/insert")
	//mac dinh ko khai bao thi luon la GET
	//@RequestMapping(value="/insert",method="PUT") khai bao PUT
	//@GetMapping(value ="/insert")
	public String insertEmployee(Employee employee) {
		employeeRepository.save(employee);
		return "redirect:/detail/" + employee.getId();
	}

	@GetMapping(value = "/delete/{id}")
	public String deleteEmployee(@PathVariable(value = "id") Long id) {
		if (employeeRepository.findById(id).isPresent()) {

			Employee employee = employeeRepository.findById(id).get();
			// suggestion: check if employee is null
			// if null, redirect to a 404 Not Found page
			employeeRepository.delete(employee);
		}
		return "redirect:/employee/list";
	}
}
